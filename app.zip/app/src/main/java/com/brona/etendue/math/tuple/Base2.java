package com.brona.etendue.math.tuple;

public interface Base2 {

    float getX();
    float getY();

}
