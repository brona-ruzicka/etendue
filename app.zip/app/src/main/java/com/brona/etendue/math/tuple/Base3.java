package com.brona.etendue.math.tuple;

public interface Base3 {

    float getX();
    float getY();
    float getZ();

}
